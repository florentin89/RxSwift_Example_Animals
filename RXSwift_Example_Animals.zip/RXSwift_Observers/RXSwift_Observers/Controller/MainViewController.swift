//
//  ViewController.swift
//  RXSwift_Observers
//
//  Created by Florentin Lupascu on 29/03/2019.
//  Copyright © 2019 Florentin Lupascu. All rights reserved.
//

import UIKit
import RxSwift

class MainViewController: UIViewController {
    
    @IBOutlet weak var welcomeLabel: UILabel!
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func selectAnimal(_ sender: UIBarButtonItem) {
    
        let detailsVC = storyboard?.instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        
        detailsVC.selectedAnimal
            .subscribe(onNext: { [weak self] character in
                self?.welcomeLabel.text = "Hello \(character)"
            }).disposed(by: disposeBag)
        
        navigationController?.pushViewController(detailsVC, animated: true)
    }
    
}

