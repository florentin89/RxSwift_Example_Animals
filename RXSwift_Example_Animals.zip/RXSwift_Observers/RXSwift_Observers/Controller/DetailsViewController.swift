//
//  DetailsViewController.swift
//  RXSwift_Observers
//
//  Created by Florentin Lupascu on 29/03/2019.
//  Copyright © 2019 Florentin Lupascu. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class DetailsViewController: UIViewController {
    
    private let selectedAnimalBehavior = BehaviorRelay(value: "User")
    
    var selectedAnimal: Observable<String> {
        return selectedAnimalBehavior.asObservable()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func animalSelected(_ sender: UIButton) {
        
        guard let animalName = sender.titleLabel?.text else {return}
        
        selectedAnimalBehavior.accept(selectedAnimalBehavior.value + animalName)
    }
}
